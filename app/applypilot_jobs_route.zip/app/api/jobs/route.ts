import { NextRequest, NextResponse } from 'next/server'

type JobResult = {
  id: string
  title: string
  company: string
  location: string
  category: string
  url: string
  source: string
  description: string
  publicationDate?: string
  fitScore?: number
}

function getSearchTerms(resumeText: string) {
  const resume = resumeText.toLowerCase()
  const terms = new Set<string>()

  if (resume.includes('hr') || resume.includes('human resources')) {
    terms.add('hr coordinator')
    terms.add('hr assistant')
    terms.add('people operations')
    terms.add('hr operations')
  }

  if (resume.includes('recruit') || resume.includes('talent acquisition')) {
    terms.add('recruiting coordinator')
    terms.add('talent acquisition specialist')
    terms.add('recruiter')
  }

  if (resume.includes('onboarding')) {
    terms.add('onboarding specialist')
    terms.add('employee onboarding')
  }

  if (resume.includes('payroll')) {
    terms.add('payroll specialist')
    terms.add('payroll coordinator')
  }

  if (resume.includes('benefits')) {
    terms.add('benefits coordinator')
    terms.add('benefits specialist')
  }

  if (resume.includes('compliance')) {
    terms.add('hr compliance')
    terms.add('compliance coordinator')
  }

  if (terms.size === 0) {
    terms.add('remote administrative coordinator')
    terms.add('operations coordinator')
    terms.add('remote assistant')
  }

  return Array.from(terms).slice(0, 6)
}

function stripHtml(value: string) {
  return value.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim()
}

function scoreJobAgainstResume(resumeText: string, job: JobResult) {
  const resume = resumeText.toLowerCase()
  const jobText = `${job.title} ${job.category} ${job.description}`.toLowerCase()

  const keywords = [
    'recruiting',
    'talent acquisition',
    'onboarding',
    'hr',
    'human resources',
    'people operations',
    'employee relations',
    'payroll',
    'benefits',
    'compliance',
    'hris',
    'ats',
    'records',
    'training',
    'coordinator',
    'assistant',
    'administrator'
  ]

  let score = 20

  for (const keyword of keywords) {
    if (resume.includes(keyword) && jobText.includes(keyword)) {
      score += 6
    }
  }

  if (job.title.toLowerCase().includes('assistant') && resume.includes('administrator')) {
    score += 15
  }

  if (job.title.toLowerCase().includes('coordinator') && resume.includes('administrator')) {
    score += 12
  }

  if (job.location.toLowerCase().includes('remote') || job.location.toLowerCase().includes('anywhere')) {
    score += 10
  }

  return Math.min(score, 98)
}

export async function POST(req: NextRequest) {
  try {
    const { resumeText } = await req.json()

    if (!resumeText || typeof resumeText !== 'string') {
      return NextResponse.json({ error: 'Resume text is required.' }, { status: 400 })
    }

    const terms = getSearchTerms(resumeText)
    const collected: JobResult[] = []

    for (const term of terms) {
      const url = `https://remotive.com/api/remote-jobs?search=${encodeURIComponent(term)}`

      const response = await fetch(url, {
        method: 'GET',
        headers: { Accept: 'application/json' },
        cache: 'no-store'
      })

      if (!response.ok) {
        continue
      }

      const data = await response.json()

      const jobs = (data.jobs || []).map((job: any) => {
        const result: JobResult = {
          id: String(job.id),
          title: job.title || 'Untitled role',
          company: job.company_name || 'Unknown company',
          location: job.candidate_required_location || 'Remote',
          category: job.category || 'Remote',
          url: job.url,
          source: 'Remotive',
          description: stripHtml(String(job.description || '')).slice(0, 3500),
          publicationDate: job.publication_date
        }

        result.fitScore = scoreJobAgainstResume(resumeText, result)
        return result
      })

      collected.push(...jobs)
    }

    const deduped = Array.from(
      new Map(collected.map(job => [`${job.company}-${job.title}`, job])).values()
    )
      .sort((a, b) => (b.fitScore || 0) - (a.fitScore || 0))
      .slice(0, 30)

    return NextResponse.json({
      searchTerms: terms,
      jobs: deduped
    })
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || 'Failed to search jobs.' },
      { status: 500 }
    )
  }
}
