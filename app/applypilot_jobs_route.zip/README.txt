# ApplyPilot Jobs Route

Upload this file to your GitHub repo at:

app/api/jobs/route.ts

What it does:
- Reads resume text from the request body
- Creates job search terms based on the resume
- Searches real remote jobs from Remotive
- Scores jobs against the resume
- Returns ranked real job listings

It does not use mock data.
It does not need an API key.
